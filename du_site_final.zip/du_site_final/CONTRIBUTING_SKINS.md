# Contribute Skins — Destiny Unwritten

We welcome **free community skins** for early builds.

## Specs (v0)
- PNG textures (sRGB), 512–2048 px (prefer 1024 if possible)
- Non-overlapping UVs preferred
- Naming: `du_<faction>_<item>_<artist>_v1.png`
- Deliverables: final PNG(s) + optional source (PSD/KRITA/PROCREATE) + one in‑engine/viewport screenshot

## License
You keep ownership; you grant us a non‑exclusive, worldwide, perpetual, royalty‑free license to use/modify/distribute the skin **inside the game & marketing**, with credit.
